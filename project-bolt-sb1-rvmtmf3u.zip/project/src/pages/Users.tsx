import React, { useState } from 'react';
import { 
  Users as UsersIcon, 
  Search, 
  Filter, 
  Plus, 
  MoreVertical,
  CheckCircle,
  Clock,
  AlertCircle,
  UserPlus,
  Trash2
} from 'lucide-react';
import Card from '../components/Card';
import { deleteUser } from '../services/userService';

const Users = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  
  const usersList = [
    { 
      id: 1, 
      name: 'John Smith', 
      email: 'john.smith@company.com', 
      department: 'Engineering', 
      status: 'active',
      onboardingStatus: 'in-progress',
      onboardingProgress: 75,
      startDate: '2025-04-01' 
    },
    { 
      id: 2, 
      name: 'Sarah Johnson', 
      email: 'sarah.johnson@company.com', 
      department: 'Marketing', 
      status: 'active',
      onboardingStatus: 'completed',
      onboardingProgress: 100,
      startDate: '2025-03-28' 
    },
    { 
      id: 3, 
      name: 'Michael Brown', 
      email: 'michael.brown@company.com', 
      department: 'HR', 
      status: 'pending',
      onboardingStatus: 'in-progress',
      onboardingProgress: 30,
      startDate: '2025-04-03' 
    },
    { 
      id: 4, 
      name: 'Emily Davis', 
      email: 'emily.davis@company.com', 
      department: 'Finance', 
      status: 'active',
      onboardingStatus: 'in-progress',
      onboardingProgress: 90,
      startDate: '2025-03-30' 
    },
    { 
      id: 5, 
      name: 'Robert Wilson', 
      email: 'robert.wilson@company.com', 
      department: 'IT', 
      status: 'pending',
      onboardingStatus: 'needs-attention',
      onboardingProgress: 10,
      startDate: '2025-04-05' 
    },
    { 
      id: 6, 
      name: 'Jennifer Taylor', 
      email: 'jennifer.taylor@company.com', 
      department: 'Sales', 
      status: 'active',
      onboardingStatus: 'completed',
      onboardingProgress: 100,
      startDate: '2025-03-15' 
    },
    { 
      id: 7, 
      name: 'David Anderson', 
      email: 'david.anderson@company.com', 
      department: 'Design', 
      status: 'active',
      onboardingStatus: 'completed',
      onboardingProgress: 100,
      startDate: '2025-03-10' 
    },
    { 
      id: 8, 
      name: 'Jessica Martinez', 
      email: 'jessica.martinez@company.com', 
      department: 'Operations', 
      status: 'pending',
      onboardingStatus: 'not-started',
      onboardingProgress: 0,
      startDate: '2025-04-10' 
    },
  ];

  const [users, setUsers] = useState(usersList);

  const handleDeleteUser = async (userId: number) => {
    try {
      setIsDeleting(true);
      await deleteUser(userId.toString());
      setUsers(users.filter(user => user.id !== userId));
      setShowDeleteConfirm(null);
    } catch (error) {
      console.error('Failed to delete user:', error);
      alert('Failed to delete user. Please try again.');
    } finally {
      setIsDeleting(false);
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    }).format(date);
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'completed':
        return { 
          icon: <CheckCircle size={14} />, 
          text: 'Completed', 
          color: 'text-green-600',
          bgColor: 'bg-green-50'
        };
      case 'needs-attention':
        return { 
          icon: <AlertCircle size={14} />, 
          text: 'Needs Attention', 
          color: 'text-red-600',
          bgColor: 'bg-red-50'
        };
      case 'not-started':
        return { 
          icon: <UserPlus size={14} />, 
          text: 'Not Started', 
          color: 'text-gray-600',
          bgColor: 'bg-gray-50'
        };
      default:
        return { 
          icon: <Clock size={14} />, 
          text: 'In Progress', 
          color: 'text-blue-600',
          bgColor: 'bg-blue-50'
        };
    }
  };

  const filteredUsers = users.filter(user => {
    const matchesSearch = 
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.department.toLowerCase().includes(searchTerm.toLowerCase());
    
    let matchesStatus = true;
    if (filterStatus !== 'all') {
      matchesStatus = user.onboardingStatus === filterStatus;
    }
    
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-800">Users</h1>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center gap-2">
          <Plus size={16} />
          New User
        </button>
      </div>

      <Card className="p-6">
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={18} className="text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search users by name, email, or department..."
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="sm:w-48">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Filter size={18} className="text-gray-400" />
              </div>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none"
              >
                <option value="all">All Status</option>
                <option value="completed">Completed</option>
                <option value="in-progress">In Progress</option>
                <option value="needs-attention">Needs Attention</option>
                <option value="not-started">Not Started</option>
              </select>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  User
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Department
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Start Date
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Onboarding Status
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Progress
                </th>
                <th scope="col" className="relative px-6 py-3">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredUsers.map((user) => {
                const statusBadge = getStatusBadge(user.onboardingStatus);
                
                return (
                  <tr key={user.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="h-10 w-10 rounded-full bg-gray-100 flex items-center justify-center text-gray-700 font-medium">
                          {user.name.split(' ').map(n => n[0]).join('')}
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">{user.name}</div>
                          <div className="text-sm text-gray-500">{user.email}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{user.department}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{formatDate(user.startDate)}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusBadge.bgColor} ${statusBadge.color} gap-1`}>
                        {statusBadge.icon}
                        {statusBadge.text}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="w-full bg-gray-200 rounded-full h-2 max-w-[150px]">
                        <div 
                          className={`h-2 rounded-full ${
                            user.onboardingStatus === 'needs-attention' 
                              ? 'bg-red-500' 
                              : user.onboardingStatus === 'completed' 
                                ? 'bg-green-500' 
                                : 'bg-blue-500'
                          }`}
                          style={{ width: `${user.onboardingProgress}%` }}
                        />
                      </div>
                      <span className="text-xs text-gray-500 mt-1">{user.onboardingProgress}%</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <div className="flex items-center justify-end">
                        {showDeleteConfirm === user.id ? (
                          <div className="flex items-center space-x-2">
                            <button
                              onClick={() => handleDeleteUser(user.id)}
                              disabled={isDeleting}
                              className="text-red-600 hover:text-red-800 font-medium text-sm"
                            >
                              Confirm
                            </button>
                            <button
                              onClick={() => setShowDeleteConfirm(null)}
                              className="text-gray-500 hover:text-gray-700 font-medium text-sm"
                            >
                              Cancel
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => setShowDeleteConfirm(user.id)}
                            className="text-gray-400 hover:text-red-600 transition-colors"
                          >
                            <Trash2 size={18} />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        
        {filteredUsers.length === 0 && (
          <div className="py-8 text-center">
            <UsersIcon size={36} className="mx-auto text-gray-300 mb-2" />
            <h3 className="text-lg font-medium text-gray-600">No users found</h3>
            <p className="text-sm text-gray-500 mt-1">
              {searchTerm 
                ? `No users match your search for "${searchTerm}"`
                : 'No users match the selected filters'}
            </p>
          </div>
        )}
      </Card>
    </div>
  );
};

export default Users;