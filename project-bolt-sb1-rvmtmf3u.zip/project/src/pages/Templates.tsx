import React, { useState } from 'react';
import { FileText, Edit2, Copy, Trash2, Plus, ChevronRight } from 'lucide-react';
import Card from '../components/Card';
import { Link } from 'react-router-dom';

const Templates = () => {
  const [templates, setTemplates] = useState([
    { 
      id: 1, 
      name: 'Engineering Onboarding', 
      department: 'Engineering',
      accessCount: 12,
      createdAt: '2025-01-15',
      isDefault: true
    },
    { 
      id: 2, 
      name: 'Marketing Team Access', 
      department: 'Marketing',
      accessCount: 8,
      createdAt: '2025-02-03',
      isDefault: true
    },
    { 
      id: 3, 
      name: 'Finance Department', 
      department: 'Finance',
      accessCount: 10,
      createdAt: '2025-02-17',
      isDefault: true
    },
    { 
      id: 4, 
      name: 'IT Support Team', 
      department: 'IT',
      accessCount: 15,
      createdAt: '2025-03-01',
      isDefault: true
    },
    { 
      id: 5, 
      name: 'HR Basic Access', 
      department: 'HR',
      accessCount: 7,
      createdAt: '2025-03-10',
      isDefault: true
    },
    { 
      id: 6, 
      name: 'Developer Lead', 
      department: 'Engineering',
      accessCount: 18,
      createdAt: '2025-03-15',
      isDefault: false
    },
  ]);

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    }).format(date);
  };

  const handleDuplicate = (template) => {
    const newTemplate = {
      ...template,
      id: templates.length + 1,
      name: `${template.name} (Copy)`,
      isDefault: false,
      createdAt: new Date().toISOString().split('T')[0]
    };
    setTemplates([...templates, newTemplate]);
  };

  const handleDelete = (id) => {
    if (window.confirm('Are you sure you want to delete this template?')) {
      setTemplates(templates.filter(template => template.id !== id));
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-800">Permission Templates</h1>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center gap-2">
          <Plus size={16} />
          Create Template
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {templates.map(template => (
          <Card key={template.id} className="p-6 relative group">
            <div className="absolute top-4 right-4 flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
              <button 
                className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
                title="Edit Template"
              >
                <Edit2 size={16} />
              </button>
              <button 
                onClick={() => handleDuplicate(template)}
                className="p-1 text-gray-400 hover:text-green-600 transition-colors"
                title="Duplicate Template"
              >
                <Copy size={16} />
              </button>
              {!template.isDefault && (
                <button 
                  onClick={() => handleDelete(template.id)}
                  className="p-1 text-gray-400 hover:text-red-600 transition-colors"
                  title="Delete Template"
                >
                  <Trash2 size={16} />
                </button>
              )}
            </div>
            
            <div className="flex items-start mb-4">
              <div className="p-3 rounded-lg bg-blue-50 text-blue-600 mr-4">
                <FileText size={20} />
              </div>
              <div>
                <div className="flex items-center">
                  <h3 className="text-lg font-semibold text-gray-800">{template.name}</h3>
                  {template.isDefault && (
                    <span className="ml-2 px-2 py-0.5 text-xs bg-gray-100 text-gray-600 rounded-full">
                      Default
                    </span>
                  )}
                </div>
                <p className="text-sm text-gray-500">
                  {template.department} • {template.accessCount} access points
                </p>
              </div>
            </div>
            
            <p className="text-sm text-gray-600 mb-4">
              Created on {formatDate(template.createdAt)}
            </p>
            
            <div className="flex justify-between items-center pt-4 border-t border-gray-100">
              <span className="text-sm text-gray-500">Last updated 3 days ago</span>
              <Link 
                to={`/templates/${template.id}`} 
                className="text-blue-600 hover:text-blue-800 flex items-center"
              >
                <span className="text-sm font-medium mr-1">View</span>
                <ChevronRight size={16} />
              </Link>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default Templates;