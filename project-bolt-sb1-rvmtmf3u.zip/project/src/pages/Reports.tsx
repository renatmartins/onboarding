import React, { useState } from 'react';
import { Calendar, Download, Filter, BarChart2, PieChart, LineChart, RefreshCw } from 'lucide-react';
import Card from '../components/Card';

const Reports = () => {
  const [dateRange, setDateRange] = useState('last-30');
  const [filterDepartment, setFilterDepartment] = useState('all');

  const formatDate = (daysAgo = 0) => {
    const date = new Date();
    date.setDate(date.getDate() - daysAgo);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    }).format(date);
  };

  const getDateRangeText = () => {
    switch (dateRange) {
      case 'last-7':
        return `${formatDate(7)} - ${formatDate()}`;
      case 'last-30':
        return `${formatDate(30)} - ${formatDate()}`;
      case 'last-90':
        return `${formatDate(90)} - ${formatDate()}`;
      default:
        return `${formatDate(30)} - ${formatDate()}`;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-800">Reports & Analytics</h1>
        <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors flex items-center gap-2">
          <Download size={16} />
          Export Data
        </button>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex items-center p-2 bg-white rounded-md border border-gray-200 shadow-sm">
          <div className="p-2">
            <Calendar size={18} className="text-gray-400" />
          </div>
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="text-sm text-gray-700 bg-transparent border-none focus:ring-0"
          >
            <option value="last-7">Last 7 days</option>
            <option value="last-30">Last 30 days</option>
            <option value="last-90">Last 90 days</option>
          </select>
        </div>

        <div className="flex items-center p-2 bg-white rounded-md border border-gray-200 shadow-sm">
          <div className="p-2">
            <Filter size={18} className="text-gray-400" />
          </div>
          <select
            value={filterDepartment}
            onChange={(e) => setFilterDepartment(e.target.value)}
            className="text-sm text-gray-700 bg-transparent border-none focus:ring-0"
          >
            <option value="all">All Departments</option>
            <option value="engineering">Engineering</option>
            <option value="marketing">Marketing</option>
            <option value="hr">HR</option>
            <option value="finance">Finance</option>
            <option value="it">IT</option>
          </select>
        </div>

        <button className="ml-auto px-2 py-2 text-gray-500 hover:text-gray-700 transition-colors flex items-center gap-1">
          <RefreshCw size={16} />
          <span className="text-sm">Refresh</span>
        </button>
      </div>

      <div className="text-sm text-gray-500">
        Showing data for: <span className="font-medium">{getDateRangeText()}</span>
        {filterDepartment !== 'all' && (
          <span> • Department: <span className="font-medium capitalize">{filterDepartment}</span></span>
        )}
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-5">
          <h3 className="text-sm font-medium text-gray-500">Average Onboarding Time</h3>
          <div className="mt-2 flex items-baseline">
            <p className="text-3xl font-semibold text-gray-900">2.4</p>
            <p className="ml-2 text-sm text-gray-500">days</p>
          </div>
          <div className="mt-1">
            <span className="text-sm text-green-600">↓ 12%</span>
            <span className="text-sm text-gray-500"> vs previous period</span>
          </div>
        </Card>

        <Card className="p-5">
          <h3 className="text-sm font-medium text-gray-500">Completed Onboardings</h3>
          <div className="mt-2 flex items-baseline">
            <p className="text-3xl font-semibold text-gray-900">24</p>
          </div>
          <div className="mt-1">
            <span className="text-sm text-green-600">↑ 5%</span>
            <span className="text-sm text-gray-500"> vs previous period</span>
          </div>
        </Card>

        <Card className="p-5">
          <h3 className="text-sm font-medium text-gray-500">Pending Tasks</h3>
          <div className="mt-2 flex items-baseline">
            <p className="text-3xl font-semibold text-gray-900">18</p>
          </div>
          <div className="mt-1">
            <span className="text-sm text-red-600">↑ 3%</span>
            <span className="text-sm text-gray-500"> vs previous period</span>
          </div>
        </Card>

        <Card className="p-5">
          <h3 className="text-sm font-medium text-gray-500">Active Onboardings</h3>
          <div className="mt-2 flex items-baseline">
            <p className="text-3xl font-semibold text-gray-900">12</p>
          </div>
          <div className="mt-1">
            <span className="text-sm text-green-600">↑ 20%</span>
            <span className="text-sm text-gray-500"> vs previous period</span>
          </div>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-medium text-gray-800">Onboarding Time by Department</h3>
            <div className="flex items-center text-sm text-gray-500">
              <BarChart2 size={16} className="mr-1" />
              Bar Chart
            </div>
          </div>
          
          <div className="h-64 flex items-end space-x-6">
            <div className="flex flex-col items-center">
              <div className="h-32 w-16 bg-blue-500 rounded-t-md"></div>
              <p className="mt-2 text-xs text-gray-500">Engineering</p>
              <p className="text-sm font-medium">2.1 days</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="h-48 w-16 bg-purple-500 rounded-t-md"></div>
              <p className="mt-2 text-xs text-gray-500">Marketing</p>
              <p className="text-sm font-medium">3.2 days</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="h-20 w-16 bg-green-500 rounded-t-md"></div>
              <p className="mt-2 text-xs text-gray-500">HR</p>
              <p className="text-sm font-medium">1.4 days</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="h-36 w-16 bg-yellow-500 rounded-t-md"></div>
              <p className="mt-2 text-xs text-gray-500">Finance</p>
              <p className="text-sm font-medium">2.4 days</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="h-24 w-16 bg-pink-500 rounded-t-md"></div>
              <p className="mt-2 text-xs text-gray-500">IT</p>
              <p className="text-sm font-medium">1.6 days</p>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-medium text-gray-800">Task Completion Rate</h3>
            <div className="flex items-center text-sm text-gray-500">
              <PieChart size={16} className="mr-1" />
              Pie Chart
            </div>
          </div>
          
          <div className="h-64 flex items-center justify-center">
            <div className="relative w-40 h-40">
              <div className="absolute inset-0 rounded-full border-[16px] border-blue-500" style={{ clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%)' }}></div>
              <div className="absolute inset-0 rounded-full border-[16px] border-green-500" style={{ clipPath: 'polygon(50% 50%, 100% 50%, 100% 100%, 50% 100%)' }}></div>
              <div className="absolute inset-0 rounded-full border-[16px] border-red-500" style={{ clipPath: 'polygon(50% 50%, 50% 100%, 0 100%, 0 50%)' }}></div>
              <div className="absolute inset-0 rounded-full border-[16px] border-yellow-500" style={{ clipPath: 'polygon(0 0, 50% 0, 50% 50%, 0 50%)' }}></div>
              <div className="absolute inset-0 rounded-full border-[16px] border-purple-500" style={{ clipPath: 'polygon(50% 0, 100% 0, 100% 50%, 50% 50%)' }}></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-2xl font-bold text-gray-700">78%</span>
              </div>
            </div>
            
            <div className="ml-8">
              <div className="space-y-3">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
                  <span className="text-sm text-gray-600">Email Setup (92%)</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                  <span className="text-sm text-gray-600">System Access (87%)</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
                  <span className="text-sm text-gray-600">Security (65%)</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></div>
                  <span className="text-sm text-gray-600">Applications (76%)</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-purple-500 rounded-full mr-2"></div>
                  <span className="text-sm text-gray-600">Resources (70%)</span>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </div>

      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-medium text-gray-800">Onboarding Trends</h3>
          <div className="flex items-center text-sm text-gray-500">
            <LineChart size={16} className="mr-1" />
            Line Chart
          </div>
        </div>
        
        <div className="h-64">
          <div className="h-full flex items-end relative">
            <div className="absolute inset-y-0 left-0 w-12 flex flex-col justify-between text-xs text-gray-500">
              <span>5.0</span>
              <span>4.0</span>
              <span>3.0</span>
              <span>2.0</span>
              <span>1.0</span>
              <span>0</span>
            </div>
            
            <div className="ml-12 flex-1 h-full flex flex-col">
              {/* Grid lines */}
              <div className="flex-1 border-b border-gray-200"></div>
              <div className="flex-1 border-b border-gray-200"></div>
              <div className="flex-1 border-b border-gray-200"></div>
              <div className="flex-1 border-b border-gray-200"></div>
              <div className="flex-1 border-b border-gray-200"></div>
              
              {/* Line chart (simplified visual representation) */}
              <div className="absolute inset-0 mt-6 ml-12 flex items-center">
                <svg className="w-full h-3/4" viewBox="0 0 300 100" preserveAspectRatio="none">
                  <path 
                    d="M0,90 L50,80 L100,85 L150,50 L200,40 L250,30 L300,20" 
                    fill="none" 
                    stroke="#3B82F6" 
                    strokeWidth="3"
                  />
                  <path 
                    d="M0,90 L50,80 L100,85 L150,50 L200,40 L250,30 L300,20" 
                    fill="url(#blue-gradient)" 
                    fillOpacity="0.2" 
                    stroke="none"
                  />
                  <defs>
                    <linearGradient id="blue-gradient" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#3B82F6" stopOpacity="0.8"/>
                      <stop offset="100%" stopColor="#3B82F6" stopOpacity="0"/>
                    </linearGradient>
                  </defs>
                </svg>
              </div>
            </div>
          </div>
          
          <div className="mt-2 ml-12 flex justify-between text-xs text-gray-500">
            <span>Jan</span>
            <span>Feb</span>
            <span>Mar</span>
            <span>Apr</span>
            <span>May</span>
            <span>Jun</span>
          </div>
        </div>
        
        <div className="mt-4 flex justify-center space-x-6">
          <div className="flex items-center">
            <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
            <span className="text-sm text-gray-600">Avg. onboarding time (days)</span>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default Reports;