import React, { useState } from 'react';
import { Edit2, Trash2, Plus, Briefcase } from 'lucide-react';
import Card from '../components/Card';

const Departments = () => {
  const [departments, setDepartments] = useState([
    { id: 1, name: 'Engineering', description: 'Software development and QA', employeeCount: 32 },
    { id: 2, name: 'Marketing', description: 'Brand management and campaigns', employeeCount: 18 },
    { id: 3, name: 'HR', description: 'Human resources and recruitment', employeeCount: 8 },
    { id: 4, name: 'Finance', description: 'Financial operations and accounting', employeeCount: 12 },
    { id: 5, name: 'IT', description: 'Infrastructure and support', employeeCount: 15 },
    { id: 6, name: 'Sales', description: 'Business development and client relations', employeeCount: 24 },
    { id: 7, name: 'Design', description: 'UX/UI and product design', employeeCount: 10 },
    { id: 8, name: 'Operations', description: 'Business operations and logistics', employeeCount: 14 },
  ]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentDepartment, setCurrentDepartment] = useState({ id: 0, name: '', description: '', employeeCount: 0 });

  const openEditModal = (department) => {
    setCurrentDepartment(department);
    setIsModalOpen(true);
  };

  const openAddModal = () => {
    setCurrentDepartment({ id: 0, name: '', description: '', employeeCount: 0 });
    setIsModalOpen(true);
  };

  const handleSave = (e) => {
    e.preventDefault();
    if (currentDepartment.id === 0) {
      // Add new department
      setDepartments([
        ...departments,
        { ...currentDepartment, id: departments.length + 1, employeeCount: 0 }
      ]);
    } else {
      // Update existing department
      setDepartments(
        departments.map(dept => 
          dept.id === currentDepartment.id ? currentDepartment : dept
        )
      );
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id) => {
    if (window.confirm('Are you sure you want to delete this department?')) {
      setDepartments(departments.filter(dept => dept.id !== id));
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-800">Departments</h1>
        <button 
          onClick={openAddModal}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center gap-2"
        >
          <Plus size={16} />
          Add Department
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {departments.map(department => (
          <Card key={department.id} className="p-6 relative group">
            <div className="absolute top-4 right-4 flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
              <button 
                onClick={() => openEditModal(department)}
                className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
              >
                <Edit2 size={16} />
              </button>
              <button 
                onClick={() => handleDelete(department.id)}
                className="p-1 text-gray-400 hover:text-red-600 transition-colors"
              >
                <Trash2 size={16} />
              </button>
            </div>
            
            <div className="flex items-center mb-4">
              <div className="p-3 rounded-lg bg-blue-50 text-blue-600 mr-4">
                <Briefcase size={20} />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-800">{department.name}</h3>
                <p className="text-sm text-gray-500">{department.employeeCount} Employees</p>
              </div>
            </div>
            
            <p className="text-gray-600 text-sm">{department.description}</p>
            
            <div className="mt-4 pt-4 border-t border-gray-100">
              <button className="text-sm text-blue-600 hover:text-blue-800 font-medium">
                View Permission Template
              </button>
            </div>
          </Card>
        ))}
      </div>

      {/* Department Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
            <h2 className="text-xl font-bold text-gray-800 mb-4">
              {currentDepartment.id === 0 ? 'Add Department' : 'Edit Department'}
            </h2>
            
            <form onSubmit={handleSave}>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Department Name
                </label>
                <input
                  type="text"
                  value={currentDepartment.name}
                  onChange={(e) => setCurrentDepartment({...currentDepartment, name: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  value={currentDepartment.description}
                  onChange={(e) => setCurrentDepartment({...currentDepartment, description: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows={3}
                />
              </div>
              
              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                >
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Departments;