import React, { useState } from 'react';
import { 
  User, 
  Shield, 
  Bell, 
  MessageSquare, 
  Send, 
  Database, 
  Code 
} from 'lucide-react';
import Card from '../components/Card';

const Settings = () => {
  const [activeTab, setActiveTab] = useState('general');
  
  const settingTabs = [
    { id: 'general', label: 'General', icon: <User size={18} /> },
    { id: 'security', label: 'Security', icon: <Shield size={18} /> },
    { id: 'notifications', label: 'Notifications', icon: <Bell size={18} /> },
    { id: 'templates', label: 'Email Templates', icon: <MessageSquare size={18} /> },
    { id: 'integrations', label: 'Integrations', icon: <Code size={18} /> },
    { id: 'data-syncing', label: 'Data Syncing', icon: <Database size={18} /> },
  ];

  // General Settings
  const [generalSettings, setGeneralSettings] = useState({
    companyName: 'Acme Corporation',
    adminEmail: 'admin@acmecorp.com',
    timeZone: 'America/New_York',
    dateFormat: 'MM/DD/YYYY',
    defaultLanguage: 'en',
    defaultDepartment: 'IT',
  });

  // Notification Settings
  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    newUserNotification: true,
    completionNotification: true,
    overdueTasksNotification: true,
    dailyReportNotification: false,
    weeklyReportNotification: true,
  });
  
  // Integration Settings
  const integrations = [
    { 
      id: 'active-directory', 
      name: 'Active Directory', 
      description: 'Sync users and groups from AD',
      connected: true,
      icon: <User size={20} className="text-blue-500" />
    },
    { 
      id: 'slack', 
      name: 'Slack', 
      description: 'Send notifications to Slack channels',
      connected: true,
      icon: <MessageSquare size={20} className="text-purple-500" />
    },
    { 
      id: 'jira', 
      name: 'Jira', 
      description: 'Create and track onboarding tasks in Jira',
      connected: false,
      icon: <Code size={20} className="text-green-500" />
    },
    { 
      id: 'azure', 
      name: 'Azure AD', 
      description: 'Manage cloud identities and access',
      connected: false,
      icon: <Shield size={20} className="text-blue-500" />
    },
    { 
      id: 'google', 
      name: 'Google Workspace', 
      description: 'Create and manage Google accounts',
      connected: true,
      icon: <Send size={20} className="text-red-500" />
    },
  ];

  // Email Templates
  const emailTemplates = [
    { 
      id: 'welcome', 
      name: 'Welcome Email', 
      subject: 'Welcome to Acme Corporation!',
      lastUpdated: '2025-03-15',
    },
    { 
      id: 'credentials', 
      name: 'Credentials Email', 
      subject: 'Your Acme Corporation Login Credentials',
      lastUpdated: '2025-03-20',
    },
    { 
      id: 'completion', 
      name: 'Onboarding Complete', 
      subject: 'Your Onboarding Process is Complete',
      lastUpdated: '2025-02-28',
    },
    { 
      id: 'action-required', 
      name: 'Action Required', 
      subject: 'Action Required: Complete Your Onboarding Tasks',
      lastUpdated: '2025-03-10',
    },
  ];

  const handleGeneralSubmit = (e) => {
    e.preventDefault();
    alert('General settings saved!');
  };

  const handleNotificationSubmit = (e) => {
    e.preventDefault();
    alert('Notification settings saved!');
  };

  const handleToggleNotification = (setting) => {
    setNotificationSettings({
      ...notificationSettings,
      [setting]: !notificationSettings[setting]
    });
  };

  const handleIntegrationToggle = (id) => {
    // In a real app, this would connect/disconnect the integration
    alert(`${id} integration status would be toggled here`);
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    }).format(date);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'general':
        return (
          <Card className="p-6">
            <h2 className="text-lg font-semibold text-gray-800 mb-4">General Settings</h2>
            <form onSubmit={handleGeneralSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Company Name
                  </label>
                  <input
                    type="text"
                    value={generalSettings.companyName}
                    onChange={(e) => setGeneralSettings({...generalSettings, companyName: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Admin Email
                  </label>
                  <input
                    type="email"
                    value={generalSettings.adminEmail}
                    onChange={(e) => setGeneralSettings({...generalSettings, adminEmail: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Time Zone
                  </label>
                  <select
                    value={generalSettings.timeZone}
                    onChange={(e) => setGeneralSettings({...generalSettings, timeZone: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="America/New_York">Eastern Time (ET)</option>
                    <option value="America/Chicago">Central Time (CT)</option>
                    <option value="America/Denver">Mountain Time (MT)</option>
                    <option value="America/Los_Angeles">Pacific Time (PT)</option>
                    <option value="Europe/London">Greenwich Mean Time (GMT)</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Date Format
                  </label>
                  <select
                    value={generalSettings.dateFormat}
                    onChange={(e) => setGeneralSettings({...generalSettings, dateFormat: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="MM/DD/YYYY">MM/DD/YYYY</option>
                    <option value="DD/MM/YYYY">DD/MM/YYYY</option>
                    <option value="YYYY-MM-DD">YYYY-MM-DD</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Default Language
                  </label>
                  <select
                    value={generalSettings.defaultLanguage}
                    onChange={(e) => setGeneralSettings({...generalSettings, defaultLanguage: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="en">English</option>
                    <option value="es">Spanish</option>
                    <option value="fr">French</option>
                    <option value="de">German</option>
                    <option value="pt">Portuguese</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Default Department
                  </label>
                  <select
                    value={generalSettings.defaultDepartment}
                    onChange={(e) => setGeneralSettings({...generalSettings, defaultDepartment: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="Engineering">Engineering</option>
                    <option value="Marketing">Marketing</option>
                    <option value="HR">HR</option>
                    <option value="Finance">Finance</option>
                    <option value="IT">IT</option>
                    <option value="Sales">Sales</option>
                  </select>
                </div>
              </div>
              
              <div className="mt-6 flex justify-end">
                <button 
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </Card>
        );
        
      case 'notifications':
        return (
          <Card className="p-6">
            <h2 className="text-lg font-semibold text-gray-800 mb-4">Notification Settings</h2>
            <form onSubmit={handleNotificationSubmit}>
              <div className="space-y-4">
                <div className="flex items-center justify-between py-3 border-b border-gray-100">
                  <div>
                    <h3 className="text-sm font-medium text-gray-800">Email Notifications</h3>
                    <p className="text-xs text-gray-500 mt-1">
                      Receive email notifications for important events
                    </p>
                  </div>
                  <div className="flex items-center">
                    <button
                      type="button"
                      onClick={() => handleToggleNotification('emailNotifications')}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${
                        notificationSettings.emailNotifications ? 'bg-blue-600' : 'bg-gray-200'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          notificationSettings.emailNotifications ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                </div>
                
                <div className="flex items-center justify-between py-3 border-b border-gray-100">
                  <div>
                    <h3 className="text-sm font-medium text-gray-800">New User Notifications</h3>
                    <p className="text-xs text-gray-500 mt-1">
                      Notify when a new user starts onboarding
                    </p>
                  </div>
                  <div className="flex items-center">
                    <button
                      type="button"
                      onClick={() => handleToggleNotification('newUserNotification')}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${
                        notificationSettings.newUserNotification ? 'bg-blue-600' : 'bg-gray-200'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          notificationSettings.newUserNotification ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                </div>
                
                <div className="flex items-center justify-between py-3 border-b border-gray-100">
                  <div>
                    <h3 className="text-sm font-medium text-gray-800">Completion Notifications</h3>
                    <p className="text-xs text-gray-500 mt-1">
                      Notify when a user completes onboarding
                    </p>
                  </div>
                  <div className="flex items-center">
                    <button
                      type="button"
                      onClick={() => handleToggleNotification('completionNotification')}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${
                        notificationSettings.completionNotification ? 'bg-blue-600' : 'bg-gray-200'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          notificationSettings.completionNotification ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                </div>
                
                <div className="flex items-center justify-between py-3 border-b border-gray-100">
                  <div>
                    <h3 className="text-sm font-medium text-gray-800">Overdue Tasks</h3>
                    <p className="text-xs text-gray-500 mt-1">
                      Notify when tasks are overdue
                    </p>
                  </div>
                  <div className="flex items-center">
                    <button
                      type="button"
                      onClick={() => handleToggleNotification('overdueTasksNotification')}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${
                        notificationSettings.overdueTasksNotification ? 'bg-blue-600' : 'bg-gray-200'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          notificationSettings.overdueTasksNotification ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                </div>
                
                <div className="flex items-center justify-between py-3 border-b border-gray-100">
                  <div>
                    <h3 className="text-sm font-medium text-gray-800">Daily Report</h3>
                    <p className="text-xs text-gray-500 mt-1">
                      Receive a daily summary report
                    </p>
                  </div>
                  <div className="flex items-center">
                    <button
                      type="button"
                      onClick={() => handleToggleNotification('dailyReportNotification')}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${
                        notificationSettings.dailyReportNotification ? 'bg-blue-600' : 'bg-gray-200'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          notificationSettings.dailyReportNotification ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                </div>
                
                <div className="flex items-center justify-between py-3 border-b border-gray-100">
                  <div>
                    <h3 className="text-sm font-medium text-gray-800">Weekly Report</h3>
                    <p className="text-xs text-gray-500 mt-1">
                      Receive a weekly summary report
                    </p>
                  </div>
                  <div className="flex items-center">
                    <button
                      type="button"
                      onClick={() => handleToggleNotification('weeklyReportNotification')}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${
                        notificationSettings.weeklyReportNotification ? 'bg-blue-600' : 'bg-gray-200'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          notificationSettings.weeklyReportNotification ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 flex justify-end">
                <button 
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </Card>
        );
        
      case 'integrations':
        return (
          <Card className="p-6">
            <h2 className="text-lg font-semibold text-gray-800 mb-4">Integrations</h2>
            <p className="text-sm text-gray-600 mb-6">
              Connect with other systems to automate your onboarding process.
            </p>
            
            <div className="space-y-4">
              {integrations.map((integration) => (
                <div 
                  key={integration.id}
                  className="flex items-center justify-between p-4 border border-gray-200 rounded-lg"
                >
                  <div className="flex items-center">
                    <div className="p-2 rounded-md bg-gray-100 mr-4">
                      {integration.icon}
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-gray-800">{integration.name}</h3>
                      <p className="text-xs text-gray-500 mt-1">{integration.description}</p>
                    </div>
                  </div>
                  
                  <div>
                    <button 
                      onClick={() => handleIntegrationToggle(integration.id)}
                      className={`px-3 py-1.5 text-sm rounded-md ${
                        integration.connected
                          ? 'bg-red-50 text-red-600 hover:bg-red-100'
                          : 'bg-blue-50 text-blue-600 hover:bg-blue-100'
                      }`}
                    >
                      {integration.connected ? 'Disconnect' : 'Connect'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
              <h3 className="text-sm font-medium text-gray-800">API Access</h3>
              <p className="text-xs text-gray-600 mt-1 mb-3">
                Use our API to build custom integrations with your internal systems.
              </p>
              <div className="flex items-center space-x-3">
                <button className="px-3 py-1.5 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700">
                  Generate API Key
                </button>
                <button className="px-3 py-1.5 text-sm bg-white border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50">
                  View Documentation
                </button>
              </div>
            </div>
          </Card>
        );
        
      case 'templates':
        return (
          <Card className="p-6">
            <h2 className="text-lg font-semibold text-gray-800 mb-4">Email Templates</h2>
            <p className="text-sm text-gray-600 mb-6">
              Customize the emails sent during the onboarding process.
            </p>
            
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Template Name
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Subject Line
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Last Updated
                    </th>
                    <th scope="col" className="relative px-6 py-3">
                      <span className="sr-only">Actions</span>
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {emailTemplates.map((template) => (
                    <tr key={template.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">{template.name}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-500">{template.subject}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-500">{formatDate(template.lastUpdated)}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button className="text-blue-600 hover:text-blue-900">
                          Edit
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            <div className="mt-6 flex justify-end">
              <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
                Add New Template
              </button>
            </div>
          </Card>
        );
        
      default:
        return (
          <Card className="p-6 flex items-center justify-center">
            <p className="text-gray-500">Settings for {activeTab} will be available soon.</p>
          </Card>
        );
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-800">Settings</h1>

      <div className="flex flex-col md:flex-row gap-6">
        {/* Sidebar */}
        <div className="md:w-64 flex-shrink-0">
          <Card className="p-4">
            <nav className="space-y-1">
              {settingTabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center px-3 py-2 w-full rounded-md transition-colors ${
                    activeTab === tab.id
                      ? 'bg-blue-50 text-blue-700'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <span className="mr-3">{tab.icon}</span>
                  <span className="text-sm font-medium">{tab.label}</span>
                </button>
              ))}
            </nav>
          </Card>
        </div>

        {/* Main Content */}
        <div className="flex-1">
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
};

export default Settings;