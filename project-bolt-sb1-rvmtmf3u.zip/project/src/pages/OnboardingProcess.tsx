import React, { useState } from 'react';
import { 
  ChevronLeft, 
  CheckCircle2, 
  Clock, 
  User, 
  Database, 
  Globe, 
  Shield,
  AlertCircle,
  CornerDownRight,
  ExternalLink,
  Upload,
  Copy,
  Link as LinkIcon
} from 'lucide-react';
import { Link, useParams } from 'react-router-dom';
import Card from '../components/Card';

const OnboardingProcess = () => {
  const { id } = useParams();
  const [activeTab, setActiveTab] = useState('progress');
  
  // Mock data for a specific employee
  const employee = {
    name: 'John Smith',
    email: 'john.smith@company.com',
    department: 'Engineering',
    position: 'Full Stack Developer',
    startDate: '2025-04-01',
    manager: 'David Johnson',
    templateName: 'Engineering Onboarding',
    progress: 75,
    status: 'in-progress',
    imageUrl: null,
  };

  // Mock data for onboarding steps
  const onboardingSteps = [
    {
      id: 1,
      category: 'Account Setup',
      icon: <User size={18} />,
      steps: [
        {
          id: 101,
          name: 'Company Email',
          status: 'completed',
          description: 'Create and set up company email account',
          completedBy: 'System',
          completedAt: '2025-04-01 09:15',
          notes: 'Email created and password sent to personal email'
        },
        {
          id: 102,
          name: 'Active Directory',
          status: 'completed',
          description: 'Create AD account and assign to Engineering group',
          completedBy: 'Admin',
          completedAt: '2025-04-01 09:30',
          notes: 'Added to Engineering-Dev group'
        },
        {
          id: 103,
          name: 'Identification Card',
          status: 'pending',
          description: 'Issue physical access card for office entry',
          assignedTo: 'HR Department',
          dueDate: '2025-04-05',
        },
      ]
    },
    {
      id: 2,
      category: 'Data Access',
      icon: <Database size={18} />,
      steps: [
        {
          id: 201,
          name: 'Project Database',
          status: 'in-progress',
          description: 'Grant access to development databases',
          assignedTo: 'DBA Team',
          startedAt: '2025-04-02 10:00',
          notes: 'Pending approval from Team Lead'
        },
        {
          id: 202,
          name: 'Shared Drives',
          status: 'completed',
          description: 'Set up access to team shared drives',
          completedBy: 'System',
          completedAt: '2025-04-02 11:30',
          notes: 'Access to Engineering folder structure granted'
        },
        {
          id: 203,
          name: 'Code Repository',
          status: 'completed',
          description: 'Grant access to GitHub repositories',
          completedBy: 'Admin',
          completedAt: '2025-04-02 13:45',
          notes: 'Added to Engineering team on GitHub'
        },
      ]
    },
    {
      id: 3,
      category: 'Applications',
      icon: <Globe size={18} />,
      steps: [
        {
          id: 301,
          name: 'Slack',
          status: 'completed',
          description: 'Set up Slack account and add to channels',
          completedBy: 'System',
          completedAt: '2025-04-01 14:00',
          notes: 'Added to #engineering, #general, and #announcements'
        },
        {
          id: 302,
          name: 'Jira',
          status: 'completed',
          description: 'Create Jira account and assign to projects',
          completedBy: 'Admin',
          completedAt: '2025-04-02 09:15',
          notes: 'Added to Web App project and Engineering team'
        },
        {
          id: 303,
          name: 'Confluence',
          status: 'in-progress',
          description: 'Set up Confluence account with correct permissions',
          assignedTo: 'Admin',
          startedAt: '2025-04-03 10:30',
        },
        {
          id: 304,
          name: 'CI/CD Pipeline',
          status: 'pending',
          description: 'Grant access to Jenkins and deployment systems',
          assignedTo: 'DevOps Team',
          dueDate: '2025-04-06',
        },
      ]
    },
    {
      id: 4,
      category: 'Security & Compliance',
      icon: <Shield size={18} />,
      steps: [
        {
          id: 401,
          name: 'Security Training',
          status: 'in-progress',
          description: 'Complete required security awareness training',
          assignedTo: 'John Smith',
          startedAt: '2025-04-03 13:00',
          dueDate: '2025-04-08',
        },
        {
          id: 402,
          name: 'VPN Access',
          status: 'pending',
          description: 'Set up VPN access for remote work',
          assignedTo: 'IT Support',
          dueDate: '2025-04-07',
        },
        {
          id: 403,
          name: 'Policy Acknowledgment',
          status: 'pending',
          description: 'Sign IT policy and data protection agreement',
          assignedTo: 'John Smith',
          dueDate: '2025-04-05',
        },
      ]
    },
  ];

  // Activity log
  const activityLog = [
    {
      id: 1,
      action: 'Completed setup of Active Directory account',
      timestamp: '2025-04-01 09:30',
      user: 'Admin',
      category: 'Account Setup'
    },
    {
      id: 2,
      action: 'Created company email account',
      timestamp: '2025-04-01 09:15',
      user: 'System',
      category: 'Account Setup'
    },
    {
      id: 3,
      action: 'Added to Slack channels',
      timestamp: '2025-04-01 14:00',
      user: 'System',
      category: 'Applications'
    },
    {
      id: 4,
      action: 'Granted access to team shared drives',
      timestamp: '2025-04-02 11:30',
      user: 'System',
      category: 'Data Access'
    },
    {
      id: 5,
      action: 'Created Jira account and assigned projects',
      timestamp: '2025-04-02 09:15',
      user: 'Admin',
      category: 'Applications'
    },
    {
      id: 6,
      action: 'Added to GitHub repositories',
      timestamp: '2025-04-02 13:45',
      user: 'Admin',
      category: 'Data Access'
    },
    {
      id: 7,
      action: 'Started security awareness training',
      timestamp: '2025-04-03 13:00',
      user: 'John Smith',
      category: 'Security & Compliance'
    },
    {
      id: 8,
      action: 'Started Confluence account setup',
      timestamp: '2025-04-03 10:30',
      user: 'Admin',
      category: 'Applications'
    },
  ];

  const getProgressColor = (status) => {
    switch (status) {
      case 'completed':
        return 'bg-green-500';
      case 'in-progress':
        return 'bg-blue-500';
      case 'needs-attention':
        return 'bg-red-500';
      default:
        return 'bg-gray-300';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 size={16} className="text-green-500" />;
      case 'in-progress':
        return <Clock size={16} className="text-blue-500" />;
      case 'pending':
        return <Clock size={16} className="text-gray-400" />;
      default:
        return <AlertCircle size={16} className="text-red-500" />;
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    }).format(date);
  };

  const formatTimestamp = (timestamp) => {
    const [date, time] = timestamp.split(' ');
    const formattedDate = formatDate(date);
    return `${formattedDate} at ${time}`;
  };

  const calculateCompletedSteps = () => {
    let completed = 0;
    let total = 0;
    
    onboardingSteps.forEach(category => {
      category.steps.forEach(step => {
        total++;
        if (step.status === 'completed') {
          completed++;
        }
      });
    });
    
    return { completed, total };
  };

  const { completed, total } = calculateCompletedSteps();
  const completionPercentage = Math.round((completed / total) * 100);

  const totalDaysInOnboarding = 14; // Example: 2 weeks onboarding period
  const daysElapsed = 3; // Example: 3 days into onboarding
  const daysRemaining = totalDaysInOnboarding - daysElapsed;

  return (
    <div className="space-y-6">
      <div className="flex items-center">
        <Link 
          to="/users" 
          className="mr-4 p-2 rounded-full hover:bg-gray-100 transition-colors"
        >
          <ChevronLeft size={20} />
        </Link>
        <h1 className="text-2xl font-bold text-gray-800">
          Onboarding Process
        </h1>
      </div>

      {/* Header */}
      <Card className="p-6">
        <div className="flex flex-col md:flex-row md:items-center">
          <div className="flex items-center mb-4 md:mb-0">
            <div className="h-16 w-16 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 text-xl font-bold">
              {employee.name.split(' ').map(n => n[0]).join('')}
            </div>
            <div className="ml-4">
              <h2 className="text-xl font-semibold text-gray-800">{employee.name}</h2>
              <div className="flex flex-col sm:flex-row sm:items-center text-gray-500 text-sm gap-y-1 sm:gap-x-2">
                <span>{employee.position}</span>
                <span className="hidden sm:inline">•</span>
                <span>{employee.department}</span>
                <span className="hidden sm:inline">•</span>
                <span>Started {formatDate(employee.startDate)}</span>
              </div>
            </div>
          </div>
          
          <div className="mt-4 md:mt-0 md:ml-auto flex flex-col sm:flex-row gap-4">
            <button className="px-4 py-2 bg-white border border-gray-300 rounded-md hover:bg-gray-50 transition-colors flex items-center justify-center gap-2">
              <Upload size={16} />
              <span>Export Report</span>
            </button>
            <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center justify-center gap-2">
              <Copy size={16} />
              <span>Send Credentials</span>
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          <div className="p-4 bg-white border border-gray-100 rounded-lg shadow-sm">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-gray-500">Progress</h3>
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                employee.status === 'needs-attention' 
                  ? 'bg-red-50 text-red-600' 
                  : employee.status === 'completed' 
                    ? 'bg-green-50 text-green-600' 
                    : 'bg-blue-50 text-blue-600'
              }`}>
                {employee.status === 'in-progress' ? 'In Progress' : 
                  employee.status === 'needs-attention' ? 'Needs Attention' : 
                  'Completed'}
              </span>
            </div>
            <div className="mt-2">
              <div className="flex items-center justify-between mb-1">
                <span className="text-3xl font-bold text-gray-900">{completionPercentage}%</span>
                <span className="text-sm text-gray-500">{completed}/{total} completed</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div 
                  className={`h-2.5 rounded-full ${getProgressColor(employee.status)}`} 
                  style={{ width: `${completionPercentage}%` }}
                />
              </div>
            </div>
          </div>
          
          <div className="p-4 bg-white border border-gray-100 rounded-lg shadow-sm">
            <h3 className="text-sm font-medium text-gray-500">Template</h3>
            <div className="mt-2 flex items-center">
              <div className="p-2 rounded-md bg-purple-50 text-purple-600">
                <FileText size={18} />
              </div>
              <div className="ml-3">
                <p className="text-base font-medium text-gray-900">{employee.templateName}</p>
                <p className="text-sm text-gray-500">{employee.department}</p>
              </div>
            </div>
          </div>
          
          <div className="p-4 bg-white border border-gray-100 rounded-lg shadow-sm">
            <h3 className="text-sm font-medium text-gray-500">Timeline</h3>
            <div className="mt-2">
              <p className="text-3xl font-bold text-gray-900">{daysRemaining} days</p>
              <p className="text-sm text-gray-500">remaining in onboarding process</p>
              <div className="w-full bg-gray-200 rounded-full h-2.5 mt-2">
                <div 
                  className="h-2.5 rounded-full bg-blue-500" 
                  style={{ width: `${(daysElapsed / totalDaysInOnboarding) * 100}%` }}
                />
              </div>
              <div className="flex justify-between mt-1 text-xs text-gray-500">
                <span>{formatDate(employee.startDate)}</span>
                <span>Target: {formatDate('2025-04-15')}</span>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('progress')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'progress'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Progress Tracking
          </button>
          <button
            onClick={() => setActiveTab('activity')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'activity'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Activity Log
          </button>
        </nav>
      </div>

      {/* Content */}
      {activeTab === 'progress' ? (
        <div className="space-y-6">
          {onboardingSteps.map((category) => (
            <Card key={category.id} className="p-6">
              <h3 className="text-lg font-semibold text-gray-800 flex items-center mb-4">
                <span className="p-2 rounded-md bg-blue-50 text-blue-600 mr-3">
                  {category.icon}
                </span>
                {category.category}
              </h3>
              
              <div className="space-y-4">
                {category.steps.map((step) => (
                  <div 
                    key={step.id} 
                    className="border border-gray-100 rounded-lg p-4 hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="flex-shrink-0">
                          {getStatusIcon(step.status)}
                        </div>
                        <div className="ml-3">
                          <h4 className="text-base font-medium text-gray-900">{step.name}</h4>
                          <p className="text-sm text-gray-500">{step.description}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className={`text-sm ${
                          step.status === 'completed' ? 'text-green-600' : 
                          step.status === 'in-progress' ? 'text-blue-600' : 
                          step.status === 'pending' ? 'text-gray-500' : 
                          'text-red-600'
                        }`}>
                          {step.status === 'completed' ? 'Completed' : 
                           step.status === 'in-progress' ? 'In Progress' : 
                           'Pending'}
                        </div>
                        <p className="text-xs text-gray-500 mt-1">
                          {step.status === 'completed' 
                            ? `By ${step.completedBy}` 
                            : step.status === 'in-progress'
                              ? `Assigned to ${step.assignedTo}`
                              : step.dueDate
                                ? `Due ${formatDate(step.dueDate)}`
                                : `Assigned to ${step.assignedTo}`
                          }
                        </p>
                      </div>
                    </div>
                    
                    {step.notes && (
                      <div className="mt-3 ml-7 pl-3 border-l-2 border-gray-200">
                        <div className="flex items-start">
                          <CornerDownRight size={14} className="text-gray-400 mr-2 mt-0.5" />
                          <p className="text-sm text-gray-600">{step.notes}</p>
                        </div>
                      </div>
                    )}
                    
                    {step.status === 'completed' && (
                      <div className="mt-2 flex justify-end">
                        <p className="text-xs text-gray-500">
                          Completed on {formatTimestamp(step.completedAt)}
                        </p>
                      </div>
                    )}
                    
                    {step.status === 'in-progress' && (
                      <div className="mt-3 flex justify-end space-x-2">
                        <button className="text-sm text-blue-600 hover:text-blue-800 flex items-center">
                          <ExternalLink size={14} className="mr-1" />
                          View Details
                        </button>
                        <button className="px-3 py-1 bg-green-600 text-white text-sm rounded-md hover:bg-green-700 transition-colors">
                          Mark as Completed
                        </button>
                      </div>
                    )}
                    
                    {step.status === 'pending' && (
                      <div className="mt-3 flex justify-end space-x-2">
                        <button className="px-3 py-1 bg-blue-600 text-white text-sm rounded-md hover:bg-blue-700 transition-colors">
                          Start Process
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Activity Log</h3>
          
          <div className="space-y-6">
            {activityLog
              .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
              .reduce((days, activity) => {
                const date = activity.timestamp.split(' ')[0];
                if (!days[date]) {
                  days[date] = [];
                }
                days[date].push(activity);
                return days;
              }, {})
              .Object.entries(days)
              .map(([date, activities], index) => (
                <div key={date} className="space-y-4">
                  <h4 className="text-sm font-medium text-gray-500">
                    {index === 0 ? 'Today' : index === 1 ? 'Yesterday' : formatDate(date)}
                  </h4>
                  
                  <div className="ml-2 space-y-4">
                    {activities.map((activity) => (
                      <div key={activity.id} className="relative pl-6 pb-4">
                        <div className="absolute top-0 left-0 h-full w-px bg-gray-200"></div>
                        <div className="absolute top-1 left-[-3px] w-7 h-7 rounded-full bg-white border-2 border-blue-500"></div>
                        
                        <div className="ml-4">
                          <p className="text-sm font-medium text-gray-900">{activity.action}</p>
                          <div className="flex items-center text-xs text-gray-500 mt-1">
                            <span>{activity.timestamp.split(' ')[1]}</span>
                            <span className="mx-1">•</span>
                            <span>{activity.user}</span>
                            <div className="ml-2 px-1.5 py-0.5 bg-gray-100 rounded text-xs">
                              {activity.category}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
              
              <div className="text-center mt-8">
                <button className="px-4 py-2 text-sm text-blue-600 hover:text-blue-700 flex items-center justify-center mx-auto">
                  <LinkIcon size={14} className="mr-1" />
                  Load More Activity
                </button>
              </div>
          </div>
        </Card>
      )}
    </div>
  );
};

export default OnboardingProcess;