import React from 'react';
import { 
  Users, 
  Layers, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  Briefcase
} from 'lucide-react';
import Card from '../components/Card';
import OnboardingStatusCard from '../components/OnboardingStatusCard';
import DepartmentDistributionChart from '../components/DepartmentDistributionChart';
import RecentActivityList from '../components/RecentActivityList';

const Dashboard = () => {
  const stats = [
    { title: 'Active Onboardings', value: '12', icon: <Users className="text-blue-500" />, change: '+20%' },
    { title: 'Total Departments', value: '8', icon: <Briefcase className="text-purple-500" />, change: '' },
    { title: 'Completed This Month', value: '24', icon: <CheckCircle className="text-green-500" />, change: '+5%' },
    { title: 'Avg. Completion Time', value: '2.4 days', icon: <Clock className="text-orange-500" />, change: '-12%' },
  ];

  const onboardingStatuses = [
    { name: 'John Smith', department: 'Engineering', progress: 75, startDate: '2025-04-01', status: 'in-progress' },
    { name: 'Sarah Johnson', department: 'Marketing', progress: 100, startDate: '2025-03-28', status: 'completed' },
    { name: 'Michael Brown', department: 'HR', progress: 30, startDate: '2025-04-03', status: 'in-progress' },
    { name: 'Emily Davis', department: 'Finance', progress: 90, startDate: '2025-03-30', status: 'in-progress' },
    { name: 'Robert Wilson', department: 'IT', progress: 10, startDate: '2025-04-05', status: 'needs-attention' },
  ];

  const recentActivities = [
    { 
      id: 1,
      user: 'Admin',
      action: 'Created new Engineering onboarding template',
      timestamp: 'Today, 10:32 AM'
    },
    { 
      id: 2,
      user: 'System',
      action: 'Completed onboarding for Sarah Johnson',
      timestamp: 'Yesterday, 4:15 PM'
    },
    { 
      id: 3,
      user: 'Admin',
      action: 'Added new access level for Marketing department',
      timestamp: 'Yesterday, 2:30 PM'
    },
    { 
      id: 4,
      user: 'System',
      action: 'Started onboarding for Robert Wilson',
      timestamp: '2 days ago'
    },
    { 
      id: 5,
      user: 'Admin',
      action: 'Updated IT department permissions template',
      timestamp: '2 days ago'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-800">Dashboard</h1>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors duration-200">
          + New Onboarding
        </button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <Card key={index} className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">{stat.title}</p>
                <p className="mt-2 text-3xl font-semibold text-gray-900">{stat.value}</p>
                {stat.change && (
                  <p className={`mt-1 text-sm ${stat.change.startsWith('+') ? 'text-green-600' : 'text-red-600'}`}>
                    {stat.change} from last month
                  </p>
                )}
              </div>
              <div className="p-3 rounded-full bg-gray-100">
                {stat.icon}
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Active Onboardings */}
        <div className="lg:col-span-2 space-y-4">
          <h2 className="text-lg font-medium text-gray-800">Active Onboardings</h2>
          <div className="space-y-4">
            {onboardingStatuses.map((employee, index) => (
              <OnboardingStatusCard key={index} employee={employee} />
            ))}
          </div>
        </div>

        {/* Department Distribution & Recent Activity */}
        <div className="space-y-6">
          <Card className="p-6">
            <h2 className="text-lg font-medium text-gray-800 mb-4">Department Distribution</h2>
            <DepartmentDistributionChart />
          </Card>
          
          <Card className="p-6">
            <h2 className="text-lg font-medium text-gray-800 mb-4">Recent Activity</h2>
            <RecentActivityList activities={recentActivities} />
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;