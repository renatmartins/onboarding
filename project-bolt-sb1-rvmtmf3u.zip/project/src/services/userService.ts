import axios from 'axios';
import { API_CONFIG, getHeaders } from '../config/api';

export const deleteUser = async (userId: string) => {
  try {
    const response = await axios.delete(
      `${API_CONFIG.baseUrl}/users/${userId}`,
      { headers: getHeaders() }
    );
    return response.data;
  } catch (error) {
    throw new Error('Failed to delete user');
  }
};