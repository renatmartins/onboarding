export const API_CONFIG = {
  key: import.meta.env.VITE_API_KEY,
  baseUrl: import.meta.env.VITE_API_URL,
  adKey: import.meta.env.VITE_AD_INTEGRATION_KEY,
};

export const getHeaders = () => ({
  'Authorization': `Bearer ${API_CONFIG.key}`,
  'Content-Type': 'application/json',
});