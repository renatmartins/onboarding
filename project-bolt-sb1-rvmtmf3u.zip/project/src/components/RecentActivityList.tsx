import React from 'react';

interface Activity {
  id: number;
  user: string;
  action: string;
  timestamp: string;
}

interface RecentActivityListProps {
  activities: Activity[];
}

const RecentActivityList: React.FC<RecentActivityListProps> = ({ activities }) => {
  return (
    <div className="space-y-3">
      {activities.map((activity) => (
        <div key={activity.id} className="flex items-start space-x-3 pb-3 border-b border-gray-100 last:border-0">
          <div className="h-8 w-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-600 text-xs font-medium">
            {activity.user[0]}
          </div>
          <div>
            <p className="text-sm text-gray-800">
              <span className="font-medium">{activity.user}</span>{' '}
              {activity.action}
            </p>
            <p className="text-xs text-gray-500 mt-1">{activity.timestamp}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default RecentActivityList;