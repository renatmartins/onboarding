import React from 'react';
import { 
  CheckCircle, 
  Clock,
  AlertCircle, 
  ChevronRight
} from 'lucide-react';
import { Link } from 'react-router-dom';

interface EmployeeOnboarding {
  name: string;
  department: string;
  progress: number;
  startDate: string;
  status: 'in-progress' | 'completed' | 'needs-attention';
}

interface OnboardingStatusCardProps {
  employee: EmployeeOnboarding;
}

const OnboardingStatusCard: React.FC<OnboardingStatusCardProps> = ({ employee }) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    }).format(date);
  };

  const getStatusInfo = (status: string) => {
    switch (status) {
      case 'completed':
        return { 
          icon: <CheckCircle size={20} className="text-green-500" />, 
          text: 'Completed', 
          color: 'text-green-600',
          bgColor: 'bg-green-50'
        };
      case 'needs-attention':
        return { 
          icon: <AlertCircle size={20} className="text-red-500" />, 
          text: 'Needs Attention', 
          color: 'text-red-600',
          bgColor: 'bg-red-50'
        };
      default:
        return { 
          icon: <Clock size={20} className="text-blue-500" />, 
          text: 'In Progress', 
          color: 'text-blue-600',
          bgColor: 'bg-blue-50'
        };
    }
  };

  const statusInfo = getStatusInfo(employee.status);

  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-100 transition-all duration-200 hover:shadow-md">
      <div className="p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="h-12 w-12 rounded-full bg-gray-100 flex items-center justify-center text-gray-700 font-medium">
              {employee.name.split(' ').map(n => n[0]).join('')}
            </div>
            <div>
              <h3 className="text-lg font-medium text-gray-800">{employee.name}</h3>
              <p className="text-sm text-gray-500">{employee.department} • Started {formatDate(employee.startDate)}</p>
            </div>
          </div>
          
          <div className="mt-4 sm:mt-0 flex items-center space-x-3">
            <div className={`py-1 px-3 rounded-full ${statusInfo.bgColor} ${statusInfo.color} text-xs font-medium flex items-center space-x-1`}>
              {statusInfo.icon}
              <span>{statusInfo.text}</span>
            </div>
            <Link to={`/onboarding/1`} className="text-blue-600 hover:text-blue-800">
              <ChevronRight size={20} />
            </Link>
          </div>
        </div>
        
        <div className="mt-4">
          <div className="flex items-center justify-between mb-1">
            <span className="text-sm font-medium text-gray-600">Onboarding progress</span>
            <span className="text-sm font-medium text-gray-900">{employee.progress}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div 
              className={`h-2.5 rounded-full ${
                employee.status === 'needs-attention' 
                  ? 'bg-red-500' 
                  : employee.status === 'completed' 
                    ? 'bg-green-500' 
                    : 'bg-blue-500'
              }`} 
              style={{ width: `${employee.progress}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default OnboardingStatusCard;